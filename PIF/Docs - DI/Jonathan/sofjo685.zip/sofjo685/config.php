<?php
// config.php - Database configuration and connection
// This file contains the database connection settings for the Indoor Climate Data Website.
// It uses PDO for secure database interactions.
// Purpose: Establish a connection to the MySQL database using the provided credentials.
// This ensures all database operations in the website are secure and efficient.

$host = 'localhost:3306'; // Database host with port (e.g., localhost:3306 for local MySQL server)
$dbname = 'sofjo685_pif'; // Database name as per the project schema
$username = 'sofjo685'; // Database username for authentication
$password = 'Jojo+6842-'; // Database password for authentication

// Create PDO connection
// Disable displaying errors to users in production; ensure errors are logged instead.
// Set `display_errors` to '0' so internal details are not exposed to end-users.
@ini_set('display_errors', '0');
@ini_set('display_startup_errors', '0');
@ini_set('log_errors', '1');
// Optionally set a custom error log path via php.ini or environment; leave default otherwise.
error_reporting(E_ALL & ~E_DEPRECATED & ~E_STRICT);
// PDO (PHP Data Objects) is used for database access to prevent SQL injection and provide better error handling.
try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); // Throw exceptions on errors for better debugging
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC); // Fetch results as associative arrays
} catch (PDOException $e) {
    // If connection fails, log detailed error and show generic message
    error_log('Database connection failed: ' . $e->getMessage());
    die("Database connection failed. Please contact the administrator.");
}

// If Composer autoloader is present, require it so libraries (PHPMailer) are available
$composerAutoload = __DIR__ . '/../vendor/autoload.php';
if (is_file($composerAutoload)) {
    require_once $composerAutoload;
}

// Start session for user authentication
// Sessions allow the website to remember user login status across pages.
// This is essential for maintaining user state and access control.
// set secure cookie params before starting session
$secure = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] === 'https');
// Use a PHP-version-compatible approach for session cookie settings
if (defined('PHP_VERSION_ID') && PHP_VERSION_ID >= 70300) {
    session_set_cookie_params([
        'lifetime' => 0,
        'path' => '/',
        'domain' => '',
        'secure' => $secure,
        'httponly' => true,
        'samesite' => 'Lax'
    ]);
} else {
    // Fallback for older PHP: set cookie params without samesite, and attempt to set samesite via ini if supported
    session_set_cookie_params(0, '/', '', $secure, true);
    if (function_exists('ini_set')) {
        @ini_set('session.cookie_httponly', '1');
        @ini_set('session.cookie_secure', $secure ? '1' : '0');
        // session.cookie_samesite may not be available on older PHP; ignore failure
        @ini_set('session.cookie_samesite', 'Lax');
    }
}
session_start();

// Centralized error/exception handling: log details and show friendly message.
// For API requests (paths containing '/api/'), return JSON error responses.
$isApi = (strpos($_SERVER['REQUEST_URI'] ?? '', '/api/') !== false);

// SMTP configuration (direct values)
// Brevo (SMTP relay)
$smtp_host = 'smtp-relay.brevo.com';
$smtp_port = 587;
$smtp_user = '9e2514001@smtp-brevo.com';
$smtp_pass = 'xsmtpsib-d3eeff41a92df17cd86f79a64f364c28cb9ec80ef5ebe85d56ba8562d755fa51-NNB0qWK9zDrEtK9S';
$smtp_secure = 'tls'; // tls or ssl
// Use the SMTP authenticated user as default envelope/sender to improve deliverability
// (many relays require a verified sender and may drop messages from transient hostnames).
$smtp_from = $smtp_user; // e.g., 9e2514001@smtp-brevo.com

// Enable SMTP sends
$smtp_enabled = true;

// Debug: write emails to disk for local testing. Set to false in production.
$debug_emails = true; // Enable writing outgoing emails to disk for diagnosis (disable in production)

// NOTE: Application-level HTTPS enforcement removed — project runs over HTTP for local development per owner request.

set_error_handler(function($severity, $message, $file, $line) {
    // convert warnings/notices to ErrorException so they can be caught by exception handler
    throw new ErrorException($message, 0, $severity, $file, $line);
});

set_exception_handler(function($e) use ($isApi) {
    $msg = sprintf("Uncaught exception: %s in %s on line %d", $e->getMessage(), $e->getFile(), $e->getLine());
    error_log($msg . "\n" . $e->getTraceAsString());
    // Only attempt to set HTTP response code and headers if headers have not been sent yet.
    if (!headers_sent()) {
        http_response_code(500);
        if ($isApi) {
            header('Content-Type: application/json');
            echo json_encode(['ok' => false, 'error' => 'Server error']);
            exit;
        }
    }
    // For non-API requests or if headers already sent, display a friendly message (dev mode shows details).
    if (!$isApi) {
        if (ini_get('display_errors')) {
            echo '<h1>Server error</h1><p>' . htmlspecialchars($e->getMessage()) . '</p>';
        } else {
            echo '<h1>Server error</h1><p>An unexpected error occurred. Please contact the administrator.</p>';
        }
    }
    exit;
});
?>