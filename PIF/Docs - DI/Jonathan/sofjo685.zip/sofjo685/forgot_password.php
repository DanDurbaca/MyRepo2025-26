<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/inc/csrf.php';
require_once __DIR__ . '/inc/mail.php';

$msg = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!validate_csrf($_POST['csrf_token'] ?? '')) {
        $msg = 'Invalid CSRF token.';
    } else {
        $email = trim($_POST['email'] ?? '');
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $msg = 'Invalid email.';
        } else {
            // find user
            $stmt = $pdo->prepare('SELECT pk_username, firstName FROM `user` WHERE email = ? LIMIT 1');
            $stmt->execute([$email]);
            $user = $stmt->fetch();
            if (!$user) {
                // For privacy, show generic message
                $msg = 'If the address exists, you will receive a reset email.';
            } else {
                $username = $user['pk_username'];
                $token = bin2hex(random_bytes(16));
                $hashed = hash('sha256', $token);
                $expires = (new DateTimeImmutable('now'))->add(new DateInterval('PT1H'))->format('Y-m-d H:i:s');
                $ins = $pdo->prepare('INSERT INTO password_reset (pkfk_username, token, type, expires_at) VALUES (?, ?, "password_reset", ?)');
                $ins->execute([$username, $hashed, $expires]);

                $resetUrl = sprintf('%s/reset_password.php?token=%s', rtrim(dirname($_SERVER['SCRIPT_NAME']), '/'), $token);
                $body = "<p>Hello " . htmlspecialchars($user['firstName']) . ",</p><p>Click to reset your password: <a href=\"$resetUrl\">Reset password</a></p>";
                send_mail($email, 'Password reset', $body);
                $msg = 'If the address exists, you will receive a reset email.';
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forgot Password - Indoor Climate Data Website</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <?php require_once __DIR__ . '/_header.php'; ?>
    <main>
        <div class="container-small">
            <h2>Forgot Password</h2>
            <?php if ($msg) echo '<p class="message info">' . htmlspecialchars($msg) . '</p>'; ?>
            <form method="post">
                <?php echo csrf_input(); ?>
                <label for="email">Email:</label>
                <input type="email" id="email" name="email" required>
                <button class="btn btn-success" type="submit">Send reset link</button>
            </form>
            <p><a href="login.php">Back to Login</a></p>
        </div>
    </main>
</body>
</html>
