<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Indoor Climate</title>
    <link rel="stylesheet" href="../css/style.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="../js/app.js"></script>
</head>
<body>
    <?php
    $pageTitle = 'Dashboard';
    require_once '../config.php';
    require_once __DIR__ . '/../_header.php';
    // ensure user is logged in and username is available for queries
    if (!isset($_SESSION['username'])) {
        header('Location: ../login.php');
        exit;
    }
    $username = $_SESSION['username'];
    ?>
    <div class="container">
        <h1>Dashboard</h1>
        <p>Welcome to your dashboard! Monitor your indoor climate data.</p>

        <div class="row">
            <div class="col-half">
                <div class="box">
                    <div class="box-header">Live Measurements</div>
                    <div class="form-group">
                        <label for="station_select">Select Station</label>
                        <select id="station_select">
                            <?php
                            // Load user's stations
                            $stmt = $pdo->prepare("SELECT pk_serialNumber, name FROM station WHERE fk_user_owns = ?");
                            $stmt->execute([$username]);
                            $first = '';
                            while ($s = $stmt->fetch()) {
                                if ($first === '') $first = $s['pk_serialNumber'];
                                echo "<option value='" . htmlspecialchars($s['pk_serialNumber']) . "'>" . htmlspecialchars($s['name'] . ' (' . $s['pk_serialNumber'] . ')') . "</option>";
                            }
                            ?>
                        </select>
                    </div>

                    <div class="row">
                        <div class="col">
                            <div class="form-group">
                                <label for="start_date">Start Date</label>
                                <input type="datetime-local" id="start_date" value="<?php echo date('Y-m-d\TH:i', strtotime('-1 hour')); ?>">
                            </div>
                        </div>
                        <div class="col">
                            <div class="form-group">
                                <label for="end_date">End Date</label>
                                <input type="datetime-local" id="end_date" value="<?php echo date('Y-m-d\TH:i'); ?>">
                            </div>
                        </div>
                    </div>

                    <p>
                        <button type="button" class="btn btn-primary" id="updateChartBtn">Update Chart</button>
                        <button type="button" class="btn btn-secondary" id="resetDatesBtn">Reset</button>
                    </p>

                    <?php if ($first === ''): ?>
                        <p class="text-muted">You don't have any stations yet. <a href="stations.php">Claim or register a station</a> to see live measurements.</p>
                    <?php else: ?>
                        <div class="chart-container">
                            <canvas id="liveChart"></canvas>
                        </div>
                        <p class="text-small text-muted">Updates every 10 seconds</p>
                    <?php endif; ?>
                </div>
            </div>
            <div class="col-half">
                <div class="box">
                    <div class="box-header">Quick Stats</div>
                    <div id="quick-stats"><p>Loading...</p></div>
                </div>

                <div class="box">
                    <div class="box-header">Quick Links</div>
                    <p>
                        <a href="stations.php" class="btn btn-primary">Stations</a>
                        <a href="collections.php" class="btn btn-success">Collections</a>
                        <a href="data.php" class="btn btn-secondary">View Data</a>
                        <a href="friends.php" class="btn btn-warning">Friends</a>
                    </p>
                </div>
            </div>
        </div>
    </div>

    <script>
    $(document).ready(function() {
        var select = $('#station_select');
        var chartCanvas = document.getElementById('liveChart');

        // Only initialize chart if canvas exists (user has stations)
        var chart = null;
        if (chartCanvas) {
            var ctx = chartCanvas.getContext('2d');
            chart = new Chart(ctx, {
                type: 'line',
                data: {
                    labels: [],
                    datasets: [
                        {
                            label: 'Temperature (°C)',
                            data: [],
                            borderColor: 'rgba(255,99,132,1)',
                            backgroundColor: 'rgba(255,99,132,0.1)',
                            tension: 0.2,
                            fill: true
                        },
                        {
                            label: 'Humidity (%)',
                            data: [],
                            borderColor: 'rgba(54,162,235,1)',
                            backgroundColor: 'rgba(54,162,235,0.1)',
                            tension: 0.2,
                            fill: true
                        },
                        {
                            label: 'Air Quality',
                            data: [],
                            borderColor: 'rgba(75,192,192,1)',
                            backgroundColor: 'rgba(75,192,192,0.1)',
                            tension: 0.2,
                            fill: true
                        }
                    ]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    scales: {
                        x: { display: true, title: { display: true, text: 'Time' } },
                        y: { display: true }
                    },
                    plugins: { legend: { display: true, position: 'top' } }
                }
            });
        }

        function fetchAndUpdateChart() {
            var station = select.val();
            if (!station) return;

            var startDate = $('#start_date').val();
            var endDate = $('#end_date').val();

            $.ajax({
                url: '../api/measurements.php',
                method: 'GET',
                data: { station: station, limit: 200, start_date: startDate, end_date: endDate },
                dataType: 'json',
                success: function(response) {
                    if (response.ok && response.measurements && chart) {
                        var data = response.measurements;
                        var labels = data.map(function(d) { return new Date(d.timestamp).toLocaleTimeString(); });
                        var temps = data.map(function(d) { return d.temperature; });
                        var hums = data.map(function(d) { return d.humidity; });
                        var gases = data.map(function(d) { return d.air_quality; });

                        chart.data.labels = labels;
                        chart.data.datasets[0].data = temps;
                        chart.data.datasets[1].data = hums;
                        chart.data.datasets[2].data = gases;
                        chart.update('none');
                    }
                }
            });
        }

        function loadQuickStats() {
            var station = select.val();
            if (!station) {
                $('#quick-stats').html('<p class="text-muted">Select a station to view stats.</p>');
                return;
            }

            $.ajax({
                url: '../api/measurements.php',
                method: 'GET',
                data: { station: station, limit: 1 },
                dataType: 'json',
                success: function(response) {
                    if (response.ok && response.measurements && response.measurements.length > 0) {
                        var latest = response.measurements[0];
                        $('#quick-stats').html(
                            '<div class="row">' +
                            '<div class="col stat-box"><div class="number">' + latest.temperature + '°C</div><div class="label">Temperature</div></div>' +
                            '<div class="col stat-box"><div class="number">' + latest.humidity + '%</div><div class="label">Humidity</div></div>' +
                            '<div class="col stat-box"><div class="number">' + latest.air_quality + '</div><div class="label">Air Quality</div></div>' +
                            '</div>' +
                            '<p class="text-small text-muted mt-20">Last: ' + new Date(latest.timestamp).toLocaleString() + '</p>'
                        );
                    } else {
                        $('#quick-stats').html('<p class="text-muted">No data available.</p>');
                    }
                },
                error: function() {
                    $('#quick-stats').html('<p class="text-muted">Failed to load stats.</p>');
                }
            });
        }

        // Initial load
        if (select.val() && chart) {
            fetchAndUpdateChart();
            loadQuickStats();
        }

        select.on('change', function() {
            if (chart) fetchAndUpdateChart();
            loadQuickStats();
        });

        $('#updateChartBtn').on('click', function() {
            if (chart) fetchAndUpdateChart();
            loadQuickStats();
        });

        $('#resetDatesBtn').on('click', function() {
            var now = new Date();
            var oneHourAgo = new Date(now.getTime() - 60 * 60 * 1000);
            $('#start_date').val(oneHourAgo.toISOString().slice(0, 16));
            $('#end_date').val(now.toISOString().slice(0, 16));
            if (chart) fetchAndUpdateChart();
            loadQuickStats();
        });

        // Auto-refresh
        setInterval(function() {
            if (select.val() && chart) {
                fetchAndUpdateChart();
                loadQuickStats();
            }
        }, 10000);
    });
    </script>
</body>
</html>