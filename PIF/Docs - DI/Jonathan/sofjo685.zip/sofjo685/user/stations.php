<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Stations - Indoor Climate</title>
    <link rel="stylesheet" href="../css/style.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="../js/app.js"></script>
</head>
<body>
    <?php
    $pageTitle = 'Stations';
    require_once '../config.php';
    require_once __DIR__ . '/../_header.php';
    require_once __DIR__ . '/../inc/csrf.php';

    // Check login
    if (!isset($_SESSION['username'])) {
        header('Location: ../login.php');
        exit;
    }
    $username = $_SESSION['username'];

    // Handle form submissions
    $message = '';
    $messageType = 'info';
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        // Save edited station (owner editing name/description)
        if (isset($_POST['save_station'])) {
            if (!validate_csrf($_POST['csrf_token'] ?? '')) {
                $message = 'Invalid CSRF token.';
                $messageType = 'danger';
            } else {
                $edit_serial = trim($_POST['edit_serial'] ?? '');
                $edit_name = trim($_POST['edit_name'] ?? '');
                $edit_description = trim($_POST['edit_description'] ?? '');
                if ($edit_serial === '' || $edit_name === '') {
                    $message = 'Serial and name are required.';
                    $messageType = 'warning';
                } else {
                    // ensure current user owns the station
                    $chk = $pdo->prepare("SELECT 1 FROM station WHERE pk_serialNumber = ? AND fk_user_owns = ?");
                    $chk->execute([$edit_serial, $username]);
                    if (!$chk->fetch()) {
                        $message = 'Unauthorized to edit this station.';
                        $messageType = 'danger';
                    } else {
                        $upd = $pdo->prepare("UPDATE station SET name = ?, description = ? WHERE pk_serialNumber = ?");
                        $upd->execute([$edit_name, $edit_description, $edit_serial]);
                        $message = 'Station updated.';
                        $messageType = 'success';
                    }
                }
            }
        }

        // Claim by provision token (QR)
        if (isset($_POST['claim_with_provision'])) {
            if (!validate_csrf($_POST['csrf_token'] ?? '')) {
                $message = 'Invalid CSRF token.';
                $messageType = 'danger';
            } else {
                $prov_serial = trim($_POST['prov_serial'] ?? '');
                $prov_token = trim($_POST['prov_token'] ?? '');
                if ($prov_serial === '' || $prov_token === '') {
                    $message = 'Provide both serial and token.';
                    $messageType = 'warning';
                } else {
                    // verify provision record
                    $stmt = $pdo->prepare('SELECT id, expires_at FROM station_provision WHERE pkfk_station = ? AND token = ? LIMIT 1');
                    $stmt->execute([$prov_serial, hash('sha256', $prov_token)]);
                    $row = $stmt->fetch();
                    if (!$row) {
                        $message = 'Invalid provision token.';
                        $messageType = 'danger';
                    } elseif (new DateTimeImmutable($row['expires_at']) < new DateTimeImmutable('now')) {
                        $message = 'Provision token expired.';
                        $messageType = 'warning';
                    } else {
                        $upd = $pdo->prepare('UPDATE station SET fk_user_owns = ? WHERE pk_serialNumber = ? AND fk_user_owns IS NULL');
                        $upd->execute([$username, $prov_serial]);
                        if ($upd->rowCount() > 0) {
                            // remove provision row
                            $pdo->prepare('DELETE FROM station_provision WHERE id = ?')->execute([$row['id']]);
                            $message = 'Station claimed successfully via token!';
                            $messageType = 'success';
                        } else {
                            $message = 'Station could not be claimed (maybe already claimed).';
                            $messageType = 'warning';
                        }
                    }
                }
            }
        }

        // Claim station: prefer typed serial, otherwise dropdown
        if (isset($_POST['claim_station'])) {
            if (!validate_csrf($_POST['csrf_token'] ?? '')) {
                $message = 'Invalid CSRF token.';
                $messageType = 'danger';
            } else {
                $serial = trim($_POST['station_serial'] ?? '');
                if ($serial === '') $serial = trim($_POST['station_id'] ?? '');
                if ($serial === '') {
                    $message = 'No station specified.';
                    $messageType = 'warning';
                } else {
                    // basic serial validation
                    if (!preg_match('/^[A-Za-z0-9_\-]{1,64}$/', $serial)) {
                        $message = 'Invalid serial format.';
                        $messageType = 'danger';
                    } else {
                        $stmt = $pdo->prepare("UPDATE station SET fk_user_owns = ? WHERE pk_serialNumber = ? AND fk_user_owns IS NULL");
                        $stmt->execute([$username, $serial]);
                        if ($stmt->rowCount() > 0) {
                            $message = 'Station claimed successfully!';
                            $messageType = 'success';
                        } else {
                            $message = 'Station could not be claimed (maybe already claimed or not registered).';
                            $messageType = 'warning';
                        }
                    }
                }
            }
        }
    }
    ?>
    <div class="container">
        <h1>Your Stations</h1>
        <?php if (!empty($message)): ?>
            <div class="alert alert-<?php echo $messageType; ?>"><?php echo htmlspecialchars($message); ?></div>
        <?php endif; ?>

        <h2>Owned Stations</h2>
        <?php
        // List user's owned stations
        $stmt = $pdo->prepare("SELECT pk_serialNumber, name, description FROM station WHERE fk_user_owns = ?");
        $stmt->execute([$username]);
        $stations = $stmt->fetchAll();
        if (count($stations) > 0):
        ?>
        <table>
            <thead>
                <tr>
                    <th>Serial</th>
                    <th>Name</th>
                    <th>Description</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($stations as $station):
                    $sn = htmlspecialchars($station['pk_serialNumber']);
                    $n = htmlspecialchars($station['name']);
                    $d = htmlspecialchars($station['description']);
                ?>
                <tr>
                    <td><?php echo $sn; ?></td>
                    <td><?php echo $n; ?></td>
                    <td><?php echo $d ?: '-'; ?></td>
                    <td>
                        <button type="button" class="btn btn-sm btn-primary" onclick="editStation('<?php echo $sn; ?>', '<?php echo addslashes($n); ?>', '<?php echo addslashes($d); ?>')">Edit</button>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <?php else: ?>
        <p class="text-muted">You don't have any stations yet. Claim one below.</p>
        <?php endif; ?>

        <!-- Edit Station Form (hidden by default) -->
        <div id="editForm" class="box" style="display: none; max-width: 400px;">
            <div class="box-header">Edit Station</div>
            <form method="post">
                <?php echo csrf_input(); ?>
                <input type="hidden" name="edit_serial" id="edit_serial">
                <div class="form-group">
                    <label for="edit_name">Name</label>
                    <input type="text" id="edit_name" name="edit_name" required>
                </div>
                <div class="form-group">
                    <label for="edit_description">Description</label>
                    <textarea id="edit_description" name="edit_description" rows="2"></textarea>
                </div>
                <button type="submit" name="save_station" class="btn btn-primary">Save</button>
                <button type="button" class="btn btn-secondary" onclick="$('#editForm').hide()">Cancel</button>
            </form>
        </div>

        <h2>Claim a Station</h2>
        <div class="row">
            <div class="col-half">
                <div class="box">
                    <div class="box-header">Claim by Serial</div>
                    <form method="post">
                        <?php echo csrf_input(); ?>
                        <div class="form-group">
                            <label for="station_serial">Station Serial</label>
                            <input type="text" id="station_serial" name="station_serial" placeholder="e.g. SN-1001">
                        </div>
                        <button type="submit" name="claim_station" class="btn btn-success">Claim</button>
                    </form>
                </div>
            </div>
            <div class="col-half">
                <div class="box">
                    <div class="box-header">Select Available Station</div>
                    <form method="post">
                        <?php echo csrf_input(); ?>
                        <div class="form-group">
                            <label for="station_id">Available Stations</label>
                            <select id="station_id" name="station_id">
                                <option value="">Select a station</option>
                                <?php
                                $stmt = $pdo->query("SELECT pk_serialNumber, name FROM station WHERE fk_user_owns IS NULL");
                                while ($station = $stmt->fetch()) {
                                    echo "<option value='" . htmlspecialchars($station['pk_serialNumber']) . "'>" . htmlspecialchars($station['name']) . " (" . htmlspecialchars($station['pk_serialNumber']) . ")</option>";
                                }
                                ?>
                            </select>
                        </div>
                        <button type="submit" name="claim_station" class="btn btn-success">Claim</button>
                    </form>
                </div>
            </div>
        </div>

        <div class="box" style="max-width: 600px;">
            <div class="box-header">Claim by Provision Token (QR)</div>
            <p class="text-small">If you scanned a QR code, enter serial and token below.</p>
            <form method="post">
                <?php echo csrf_input(); ?>
                <div class="row">
                    <div class="col">
                        <div class="form-group">
                            <label for="prov_serial">Station Serial</label>
                            <input type="text" id="prov_serial" name="prov_serial" placeholder="SN-1001">
                        </div>
                    </div>
                    <div class="col">
                        <div class="form-group">
                            <label for="prov_token">Provision Token</label>
                            <input type="text" id="prov_token" name="prov_token" placeholder="token">
                        </div>
                    </div>
                </div>
                <button type="submit" name="claim_with_provision" class="btn btn-success">Claim</button>
            </form>
        </div>
    </div>

<script>
function editStation(serial, name, desc) {
    $('#edit_serial').val(serial);
    $('#edit_name').val(name);
    $('#edit_description').val(desc);
    $('#editForm').show();
    $('html, body').animate({ scrollTop: $('#editForm').offset().top - 20 }, 300);
}
</script>
</body>
</html>