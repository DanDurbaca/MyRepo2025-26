// app.js - Common JavaScript utilities for AJAX and UI enhancements

// Global AJAX setup
$.ajaxSetup({
    headers: {
        'X-CSRF-Token': $('meta[name="csrf-token"]').attr('content') || ''
    }
});

// Simple toast notification function (no Bootstrap)
function showToast(message, type = 'info') {
    // Create toast container if needed
    if (!$('#toast-container').length) {
        $('body').append('<div id="toast-container"></div>');
    }

    // Create toast element
    const toast = $('<div class="toast toast-' + type + '">' + message + '</div>');
    $('#toast-container').append(toast);

    // Auto-remove after 4 seconds
    setTimeout(function() {
        toast.fadeOut(300, function() {
            toast.remove();
        });
    }, 4000);
}

// AJAX form submission
function ajaxSubmitForm(form, successCallback, errorCallback) {
    // Accept: HTMLFormElement, jQuery object, or selector
    const $form = $(form);
    const formEl = ($form && $form.length) ? $form[0] : form;
    if (!(formEl instanceof HTMLFormElement)) {
        throw new TypeError("ajaxSubmitForm: 'form' must be a form element, selector, or jQuery form object");
    }
    const submitBtn = $form.find('button[type="submit"]');
    const originalText = submitBtn.html();

    // Disable button and show loading
    submitBtn.prop('disabled', true).text('Loading...');

    const formData = new FormData(formEl);

    $.ajax({
        url: $form.attr('action') || window.location.pathname,
        method: $form.attr('method') || 'POST',
        data: formData,
        processData: false,
        contentType: false,
        dataType: 'json',
        success: function(response) {
            submitBtn.prop('disabled', false).html(originalText);
            if (response.success || response.ok) {
                showToast(response.message || 'Success!', 'success');
                if (successCallback) successCallback(response);
            } else {
                showToast(response.error || response.message || 'An error occurred', 'error');
                if (errorCallback) errorCallback(response);
            }
        },
        error: function(xhr, status, error) {
            submitBtn.prop('disabled', false).html(originalText);
            Swal.fire({
                title: 'Network Error',
                text: 'Please check your connection and try again.',
                icon: 'error',
                confirmButtonText: 'OK'
            });
            if (errorCallback) errorCallback(xhr.responseJSON);
        }
    });
}

// Confirm action with SweetAlert
function confirmAction(title, text, confirmButtonText, cancelButtonText) {
    confirmButtonText = confirmButtonText || 'Yes';
    cancelButtonText = cancelButtonText || 'Cancel';
    return Swal.fire({
        title: title,
        text: text,
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: confirmButtonText,
        cancelButtonText: cancelButtonText
    });
}

// Load content dynamically
function loadContent(url, target, callback) {
    $(target).html('<p>Loading...</p>');
    $.get(url, function(data) {
        $(target).html(data);
        if (callback) callback();
    }).fail(function() {
        $(target).html('<div class="alert alert-danger">Failed to load content.</div>');
    });
}

// CSRF token for AJAX
$(document).ready(function() {
    var csrfToken = $('input[name="csrf_token"]').val();
    if (csrfToken) {
        $('meta[name="csrf-token"]').attr('content', csrfToken);
    }
});