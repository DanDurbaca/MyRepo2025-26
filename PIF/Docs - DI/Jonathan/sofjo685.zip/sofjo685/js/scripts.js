// scripts.js - JavaScript for the Indoor Climate Data Website

// Document ready event: Ensures DOM is loaded before running scripts
document.addEventListener('DOMContentLoaded', function() {
    console.log('Indoor Climate Data Website loaded'); // Log to console for debugging
    // Placeholder for future enhancements, e.g., ChartJS integration for data visualization
    // Example: Initialize charts here if ChartJS is included
    // const ctx = document.getElementById('myChart').getContext('2d');
    // const myChart = new Chart(ctx, { ... });
});