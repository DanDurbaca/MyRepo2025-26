<?php
// API to fetch measurements for a station with date-range filters and access checks
header('Content-Type: application/json');
require_once __DIR__ . '/../config.php';

if (!isset($_SESSION['username'])) {
    http_response_code(403);
    echo json_encode(['ok' => false, 'error' => 'Not authenticated']);
    exit;
}

$station = $_GET['station'] ?? '';
$limit = intval($_GET['limit'] ?? 100);
if ($limit <= 0 || $limit > 1000) $limit = 100;

// Handle date range parameters
$startDate = $_GET['start_date'] ?? null;
$endDate = $_GET['end_date'] ?? null;
$dateFilter = '';

if ($startDate) {
    $startDate = DateTime::createFromFormat('Y-m-d\TH:i', $startDate);
    if ($startDate) {
        $dateFilter .= ' AND timestamp >= ?';
    }
}

if ($endDate) {
    $endDate = DateTime::createFromFormat('Y-m-d\TH:i', $endDate);
    if ($endDate) {
        $dateFilter .= ' AND timestamp <= ?';
    }
}

// Validate station parameter
if (!$station || !preg_match('/^[A-Za-z0-9_\-]{1,64}$/', $station)) {
    http_response_code(400);
    echo json_encode(['ok' => false, 'error' => 'Invalid station parameter']);
    exit;
}

try {
    // verify station exists and access
    $stmt = $pdo->prepare('SELECT fk_user_owns FROM station WHERE pk_serialNumber = ?');
    $stmt->execute([$station]);
    $row = $stmt->fetch();
    if (!$row) {
        http_response_code(404);
        echo json_encode(['ok' => false, 'error' => 'Station not found']);
        exit;
    }

    $owner = $row['fk_user_owns'];
    $isAdmin = isset($_SESSION['is_admin']) && $_SESSION['is_admin'];
    $username = $_SESSION['username'];

    if (!$isAdmin && $owner !== $username) {
        $share = $pdo->prepare("SELECT 1 FROM station_share WHERE station_serial = ? AND shared_with = ? AND status = 'accepted'");
        $share->execute([$station, $username]);
        if (!$share->fetchColumn()) {
            // not owner or shared — deny and return JSON error
            http_response_code(403);
            echo json_encode(['ok' => false, 'error' => 'Access denied']);
            exit;
        }
    }

    $sql = 'SELECT timestamp, temperature, humidity, pressure, light, gas FROM measurement WHERE fk_station_records = ?' . $dateFilter . ' ORDER BY timestamp DESC LIMIT ' . intval($limit);
    $q = $pdo->prepare($sql);
    
    $params = [$station];
    if ($startDate) {
        $params[] = $startDate->format('Y-m-d H:i:s');
    }
    if ($endDate) {
        $params[] = $endDate->format('Y-m-d H:i:s');
    }
    
    $q->execute($params);
    $rows = $q->fetchAll();

    // return chronological order (oldest first)
    $rows = array_reverse($rows);
    // normalize field names for client
    $measurements = array_map(function($r){
        return [
            'timestamp' => $r['timestamp'],
            'temperature' => (float)$r['temperature'],
            'humidity' => (float)$r['humidity'],
            'pressure' => (float)$r['pressure'],
            'light' => (float)$r['light'],
            'air_quality' => (float)$r['gas']
        ];
    }, $rows);

    echo json_encode(['ok' => true, 'station' => $station, 'measurements' => $measurements]);
} catch (PDOException $e) {
    error_log('measurements API error: ' . $e->getMessage());
    http_response_code(500);
    echo json_encode(['ok' => false, 'error' => 'Server error']);
}

?>
